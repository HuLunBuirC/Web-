# 基础标签

## 在页面里引入图片

一般来说在页面中引入图片有两种方法：

1，使用CSS的background-image属性，为某个盒子指定一个背景图片。

2，使用HTML的img标签，引入一个标准图片。在微信小程序中是image标签。

## 使用img标签

```html
<img src="..." />
```

一般来说，img标签没有标签体，也就没有标签的结束部分。其最简单的写法如上。

## 图片引用中的绝对路径和相对路径

### 操作系统中的文件系统

在DOS和windows中文件是通过文件夹来进行组织的，想要找到某个具体的文件，就需要一条从根目录到该文件的由路径上的文件夹组织的字符串，这个字符串就是路径。

- 绝对路径就是根目录开始，一直延伸到具体文件的路径。
- 相对路径就是从当前路径开始，向具体文件的延伸。
  - ../，当前目录的上一层目录
  - ./，当前目录
  - /，当前项目的根目录

### 互联网中的路径系统

- 绝对路径就是协议开始，一延伸到具体文件的路径。
- 从某个文件平开始，向具体文件的延伸。

大部分时候，在网页中查询一张图片，使用的都相对路径。使用相对路径的前提是：系统中文件和文件夹的位置应该是固定的。

### 建立网站目录结构

目录名全为英文

```
网站名(site)
	images(所有的图片都放在这里)
	css（所有的CSS文件都放在这里）
	js(所有的js文件都放在这里)
	views(有权限控制的html文件放在这里)
	其他的所有的html文件都放在site目录的根目录中。
```

这样我们就可以使用相对路径来引用图片了。

```html
<img src="images/img_contact.gif" />
```

images/img_contact.gif，指的是当前目录下的一个子目录images中的一个文件。
当前目录指的是：正在写的这些代码所在的那个文件所在的目录。
../images/img_contact.gif，指的是当前目录的上一级目录中的images目录中的一个文件。
	/	--网络中的目录分隔符		http://www.sohu.com/admin/...	（建议使用）
	\	--操作系统目录分隔符		c:\abc\cba.txt			（这实际上是一个文件系统）

### img标签中的属性

alt，图片的替代文字，只在图片不显示的时候用来说明替代图片。
title，图片的标题，无论图片是否显示、鼠标悬停时都显示。该属性在所有的标签中都可以使用，是一个全局属性。
width，设定图片的宽度。
height，设定图片的高度。

```html 
<img src="..\images\img_contact.gif" title="提示一下" alt="这是一个图片" width="200px" height="200px" />
```

html5中废弃了部分属性，包括align，border，hspace，longdesc。

注意：

1. 尽管HTML5保留了width，height属性，但是最好直接在CSS中控制图片的大小。无论是HTML中的宽高控制还是CSS中的宽高控制，都是简单的进行图片的大小控制，没有按比例缩放的功能。
2. 面试中常会有alt属性和title属性的区别提问。
3. 在HTML5更好的在一个元素中插入图片的方法是CSS中的background-image。

## 超链接

```html
<a href="">超链接文字</a>
```

HTML5依然支持的属性如下：
href属性，指向某一个页面，或者指向当前页面的某个位置。如果没有href属性，则a标签不会展现出超链接的默认样式。如果只想展示超超链接样式，而不转向。则可以使用href="#"的方式。

target属性，一般的取值是五个。

- _self，在自身打开（安全打开，默认）；

- _blank，在新开的浏览器（新标签）中打开。
- _top，在页面的最顶端打开。
- _parent，在页面的父页面中打开。
- name，在具体的iframe标签中打开。

### 超链接样式的说明 

超链接的样式也是浏览器默认添加的。其样式为：蓝字+下划线 or 红字+红色下划线 or 紫红字+下划分划。其颜色之所以是变化的，是因为浏览器添加了默认样式，对超链接的状态进行了区分。

浏览器默认样式

```css
color: -webkit-link;			/*前景色，私有颜色*/
cursor: pointer;				/*指针类型，小手类型*/
text-decoration: underline;		/*文本装饰，下划线*/
```

### 常用的超链接

1，页间定位		从一个页面转向另外一个页面
2，锚链接（页内定位）	网页内定位

```html
<a name="aa"/>
```

锚，在html4中<a>标签没有href属性时就是一个锚，但在html5中没有href属性只是一个占位符。

```html
<a href="#aa">到最后</a>	
```

转到相应位置设定，需要注意：要加上#。#号和#号后面的内容被称为hash。
注意：锚连接的改变不会触发页面刷新，页面的历史记录中也不会新增内容。这个特点是以后SPA（单页应用）操作的入口点。
3，页间定位+锚链接		定位到其他页面的某个具体的位置上，即：

```html
<a href="page1.html#aa">测试</a>
```

hash内容一开始是用来在页面内进行定位的；由于hash改变时，页面不会刷新，所以在SPA中被大量的应用。
4，功能性链接

```html
<a href="mailto:thelongestday.yhf@gmail.com">给我发信</a>	
```

自动打开本机安装的邮件客户端如：outlook，foxmail等。

## src属性和href属性

在很多标签中都有src属性或href属性，其功能看似相近，其实有较大的不同。

- href（hypertext reference）属性，指定网络资源的位置。用于在当前文档和引用资源之间确立联系。

- src（source）属性，指向外部资源的位置，指向的内容将会嵌入到文档中当前标签所在的位置。在请求src资源时会将其指向的资源下载并应用到当前文档内。

# 元数据标签

元数据是描述数据的数据，换言之，元数据就是数据的语义，放在head标签中的标签都是元素数据标签。包括：
title，title标签中无法放置其他标签，即使放了也会被转变成纯文本。
base，指定文档的默认基地址以及链接打开方式。该标签有两个属性：href和target。
link，link标签的用途是与外部文件建立链接，该标签可以多次出现。

```java
<link rel="stylesheet" type="text/css" href="css/base.css"/>
```

- type属性，定义当前文本内容以层叠样式表（CSS）来解析
- rel属性，定义当前文档与被链接文档之间的关系，这里是调用外部文件，stylesheet即代表css样式表。rel属性允许的关键字有13个。
  - stylesheet
  - icon
  - search
  - ...
- href属性，定义被链接文档的位置。

style，在文档中声明样式时使用此标签。

type属性，在HTML5可以不加。type="text/css"

meta，标签提供关于 HTML 文档的元数据。它不会显示在页面上，但是对于机器是可读的。可用于浏览器（如何显示内容或重新加载页面），搜索引擎（关键词），或其他 web 服务。

```html
<meta http-equiv="content-type" content="text/html; charset=utf-8">
```

在HTML5中以上代码可以简写，如下：

```html
<meta charset="utf-8">
```

以上代码设置了文档的字符集。其中http-equiv属性指定了http头部信息，equiv是等价（equivalent）的缩写；content属性则指定了http头信息的取值。所以任何http的头部字符都可以写在meta标签里。

在meta中还可以利用name属性加content属性定义一系统的功能或行为的预编译指令。标准的name属性有如下几个值

- application-name，文档名
- author，文档作者
- description，文档描述
- generator，生成文档的程序
- keywords，网页关键字，用逗号分隔

SEO优化部分

```html
<!-- 页面标题<title>标签(head 头部必须) -->
<title>your title</title>
<!-- 页面关键词 keywords -->
<meta name="keywords" content="your keywords">
<!-- 页面描述内容 description -->
<meta name="description" content="your description">
<!-- 定义网页作者 author -->
<meta name="author" content="author,email address">
<!-- 定义网页搜索引擎索引方式，robotterms 是一组使用英文逗号「,」分割的值，通常有如下几种取值：none，noindex，nofollow，all，index和follow。 -->
<meta name="robots" content="index,follow">
```

viewport属性，视口控制

# 全局属性（global attribute）

全局属性是每个标签都有的属性，用来配置所有元素共有的行为。相对应的，每种标签中独有的属性，称为局部属性。HTML学习的重要一块就是对这两种属性的学习。

id属性，标签的唯一识别方式，在页面中一个标签只能有唯一的id，无论是不是相同的标签。
class属性，标签归类属性，在页面中，不同的标签或相同的标签之间，彼此都可以归为一类。
	注意：一个元素可以被归入多个类别，在class属性值中提供用多个空格分隔的多个类名。
id属性和class属性主要用于CSS和JavaScript中。其中CSS中有专门的id选择器和类选择器与之对应。

- id选择器以#号开头；class选择器以点开头。都是CSS中的基础选择器。

- document.getElementById()方法和document.getElementsByClassName()方法进行查询操作

title属性，提供了标签的额外信息，大部分浏览器用这个属性的值显示工具提示。
lang属性，用于说明标签内容使用的语言。

```html
<p lang="en">Hello HTML5</p>
```

hidden属性，布尔属性。隐藏相关标签。所谓隐藏是其形不可见，其位置也不存在。
- 布尔属性，这是一种特殊的属性，不需要设定属性值，只需要将属性添加到标签中即可。
- xhtml1.0中要求布尔属性也有属性值，写法如：hidden="hidden" 或 hidden="true"。在HTML5这些写法也可以，只是不是必须的了。
- 除了hidden之外，HTML中的所有布尔属性都遵循这些规律。

style属性，用在直接在标签中定义CSS样式。这是定义CSS的三种样式之一。
dir属性，用来规定元素中文字的方向。该属性只有两个有效值：ltr，rtl。
contenteditable属性，布尔属性。HTML5新加入的属性。当其为真时允许用户修改页面中的内容。
contextmenu属性，右键菜单功能。目前该属性支持并不广泛。
draggable和dropzone属性，拖放操作属性。
data-*属性，自定义属性。

## 自定义属性

HTML5中加入了专门的自定义属性，该类属性必须以“data-”为前缀。

在JavaScript中专门加入了dataset属性，以对应HTML中的data-*。

example：

```html
<span id="span1" data-level-id="1">测试</span>	<!--多单词时用减号分开-->
```

JavaScript中获取数据

```javascript
document.getElementById("span1").dataset.levelId;//js中不能直接读取level-id，因为会被解析成减号
```

