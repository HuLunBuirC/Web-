# 文本级语义标签

文本级语义标签一般是用于填充区块标签和分组标签，其通常以行框（inline-level box）的方式显示，在CSS中即为：display:inline或display:inline-block。

文本级语义标签包括：
a		超连接
em		侧重点的强调，可嵌套。表现为倾斜文字。HTML5中建议使用。
strong	表示内容重要性，可嵌套。表现为文字加粗。HTML5中建议使用。
small	旁注，比正文稍小
dfn		定义术语，表现为文字倾斜
abbr	缩写词，一般配合dfn使用

```HTML
<abbr title="World Wide Web">WWW</abbr>.
```

data	html5中新增标签，为元素赋以机器可读的数据，其中的value属性指定具体数据。
time	html5中新增标签，data标签的时间格式版本

```html
<time datetime="2015-07-09">9 July 2015</time>. Retrieved <date datetime="2015-07-16">16 July 2015</date>.
```

code	源码格式
var		定义变量
samp	计算机输出
kbd		用户输入
sub		下标文本
sup		上标文本
i		斜体
b		粗体
u		下划线
s		删除线
mark	高亮显示文本
ruby,rt,rp 拼音
bdi		定义文本方向，双向文本混用时使用（中文中没用处）
bdo		定议文本的显示方向，其中的dir属性具体定义方向，有ltr和rtl两个可选值
span	本身无语义，用于包含文本
br		换行
wbr	指定何处适合换行。是否换行以排版时的具体情况为准

## blockquote，q，cite标签

三个跟引述相关的标签，其中blockquote表示段落级引述内容；q表示行内的引述内容，表现为双引号的形式；cite表示引述的作品名，表现为文字倾斜。

## i、b、u、s标签

这些标签是之前被废弃的标签，在HTML5中为其增加了新的语议。

- s标签，之前表示删除线，现在表示错误的内容，经常用于电商领域表示打折前的价格。
- i标签，之前表示斜体，现在表示读的时候变调。
- b标签，之前表示黑体，现在表示关键字。
- u标签，之前表示下划线，现在表示避免歧义的注记。


example：

```html
重大优惠<small>具体事项见店内海报</small><br>
商品：<data value="ISBN:978-8-765-45378-8"><cite>三体三部曲</cite><small>&lt;I部、II部、III部&gt;</small></data>
原价：<s>￥146</s>&nbsp;现价：￥78&nbsp;出版时间:<time datetime="2015-5-9">2015-5-9</time><br>
我还会回来的<q>灰太狼</q><br>
<dfn>正十七边形尺规作图问题</dfn>以下简称为<abbr title="正十七边形尺规作图问题">作图问题</abbr><br>
<abbr>DNA</abbr>(<dfn>脱氧核糖核酸</dfn>)
<code>let value=document.getElementById("btn_register");</code><br>
<var>n</var> <var>n</var>-2<br>
<bdo dir="rtl">文本的方向</bdo>是不一样的<br>
<mark>我</mark>比较特殊<br>
<ruby>OJ<rp><rt>(Orange Juice)</rt></rp></ruby><br>
<ruby>汉<rp><rt>(han)</rt></rp></ruby><ruby>语<rp><rt>(yu)</rt></rp></ruby><br>
```

文本级语义标签中的大部分是针对性的元数据标签，这些标签对搜索引擎友好，是SEO的重点关注对象。

# 与文本相关的CSS属性

CSS文本功能主要分为三大类：字体、颜色、和文本。

## 字体样式

| 属性名       | 含义                   | 举例                     | 一般取值                |
| ------------ | ---------------------- | ------------------------ | ----------------------- |
| font-family  | 设置字体类型           | font-family:"隶书";      | 字符串                  |
| font-size    | 置字体大小             | font-size:12px;          | 12px是可能的最小取值    |
| font-style   | 设置字体风格           | font-style:italic;       | normal\|italic\|oblique |
| font-weight  | 设置字体的粗细         | font-weight:bold;        | normal\|bold\|100-900   |
| font-variant | 使用小型大写字体的字母 | font-variant:small-caps; | normal\|small-caps      |
| line-height  | 设置两行文本之间的距离 | line-height:1.5em;       | 数值\|长度\|百分比      |

有关line-height属性进行一解析

1，关于行高更准确的解释为，两行文本的基线之间的距离。所谓的基线就是“四线三格”中的第三条线。line-height属性只使用在行级元素或行内块级元素中，其作用和块级元素中的height属性差不多。

2，当行高小于字体大小时，字体不会变化，也不会被遮挡；当有多行的时候，只会出现两行文字部分重叠的情况

### 缩写
字体样式支持复合属性font。可以在一个声明中设置所有字体属性。
可设置的属性是（按顺序）：

```css
 "font-style font-variant font-weight font-size/line-height font-family"
```

注意，如果你缩写字体定义，至少要定义font-size，line-height和font-family三个值。
注意，缩写时，font-size和line-height只能通过斜杠/组成一个值，不能分开写。

例子：

```css
font: bold 12px/20px '宋体';	/*12px字体、20px行高是主流网页的标准字体和行高*/
```

最小可执行缩写为：

```css 
font:12px/20px "宋体";
```

如果不设置font-size属性，使用浏览器的默认样式，font-size:16px;

在移动端开发或需要适配移动端开发的时候，建议将font-size的取值的单改成em或rem。

## 文本属性

| 属性                | 功能描述                             | 取值                                                         |
| ------------------- | ------------------------------------ | ------------------------------------------------------------ |
| word-spacing        | 定义词与词之间的间距                 | normal、length                                               |
| letter-spacing      | 定义字母与字母间的间距               | normal、length                                               |
| **vertical-align**  | 定义文本的垂直对齐方式               | baseline、sub、super、bottom、text-bottom、top、middle、%、长度 |
| **text-decoration** | 定义文本的修饰线                     |                                                              |
| text-indent         | 定义文本的首行缩进                   | lengthpx、%                                                  |
| **text-align**      | 定义文本的水平对齐方式               | left、center、right、justify                                 |
| text-transform      | 定义文本大小写                       | none、uppercase、lowercase、capitalize(首字母大写)、         |
| **text-shadow**     | 定义文本阴影效果                     |                                                              |
| **white-space**     | 定义文字之间和文本之间的空白字符间距 | normal、nowarp、pre、pre-wrap、pre-line                      |
| direction           | 控制文本流入的方向                   | lrt(默认值)、rtl、inherit                                    |

### 对text-align和vertical-align的进一步解析

text-align属性为水平对齐

值		说明
left		把文本排列到左边。默认值：由浏览器决定
right	把文本排列到右边
center	把文本排列到中间
justify	实现两端对齐文本效果（为了达到这种效果，会在行内自动调整字间距）

vertical-align属性为垂直对齐

vertical-align属性可以影响inline、inline-block、table-cell元素垂直方向上的布局。

其可能的取值包括：

-  小写字母x的下边缘线就是baseline，也称为“基线”。baseline本身有复杂的确定规则。
- sub、super，将baseline降低、升高到下标、上标的位置上。sub的值相当于，`<sub>`标签，super亦然。
- top、text-top，把元素的顶端与行中最高元素（父体的顶端）的顶端对齐
- middle，把此元素放置在父元素的中部
- bottom、text-bottom，把元素的顶端与行中最低的元素的端底（父元素字体的底端）对齐。
- percentage，百分比。
- lenght（上移（正值）或下移（负值）的距离，单位px。）

解析：需要注意的是以上大部分取值都是将文本与父元素的某个位置对齐，比如baseline，就是与父元素的基线对齐；text-top就是让文本与父元素字体的顶端对齐。只有sub、super、percentage、lenght四个取值只于文本本身有关。

### 对text-indent属性的进一步解析

text-indent属性常用于隐藏网站的文字标题，一般的写法如下：

```css
<header id="main_header">
    <h1 style="text-indent: -9999px;font:12px/20px '微软雅黑';text-align:left;">
    	NNBlog
    </h1>
</header>
```

### 对text-decoration属性的进一步解析

none		默认值，定义的标准文本。
underline	设置文本的下划线。
overline		设置文本的上划线。
line-through	设置文本的删除线。
blink		设置文本闪烁。此值只在firefox浏览器中有效，在IE中无效。

### 对text-shadow属性的进一步解析

语法及其解析：

```css
text-shadow:[color] x-offset y-offset [blur-radius],[...];
```

1. color，阴影颜色，可选，没有设置的话以文本颜色为阴影颜色。该值也可以放在最后。
2. x-offset，x轴位移，指定阴影在x轴上的位移。为正值时阴影在对象的右边，反之在左边。
3. y-offset，y轴位移，指定阴影在y轴上的位移。为正值时在对象的底部，返之在顶部。
4. blur-radius，阴影模糊半径，可选参数。只能为正值，值越大，阴影边缘就越模糊。为0时没有模糊效果。单位为px。

### 对white-space属性的进一步解析

white-space属性指定对文本内容中空格和换行符的处理方式。

- normal，为默认样式，表示合并空格，多个相邻空格合并成一个；忽略除br标签之外的其他换行符。
- nowrap，也合并空格，但是不会根据容器大小换行，表示不换行。 
- pre，保持源码中的空格，有几个空格算几个空格显示，同时换行只认源码中的换行和br标签。 
- pre-wrap，保留空格，并且除了碰到源码中的换行和br会换行外，还会自适应容器的边界进行换行。 
- pre-line，合并空格，遇到源码中的换行和br会换行，碰到容器的边界也会换行。 

## 文本溢出属性

text-overflow属性是CSS3中新的属性，其可能的取值为：clip或ellipsis。

clip，不显示省略标记。ellipsis，显示省略标记。所谓省略标记指的在是最后字符中插入...。

实现文本溢出加省略标记，还需要另外两个属性配合：white-space:nowrap；overflow:hidden。

例子：

```html
<section class="title1">
	<a href="#">库布其沙漠精品、VIP、纯玩、无购物精致一日游</a>
</section>
```

css

```css
.title1{
    width:400px;
    font:bold 20px/35px '雅黑';
    text-overflow: ellipsis;	/*添加省略符号*/
    white-space: nowrap;		/*不换行*/
    overflow: hidden;			/*超出范围隐藏*/
}
```

## 指针样式属性

cursor属性，鼠标的样式
	default	默认的箭头
	pointer	小手
	wait		沙漏
	help	带问号的箭头
	text		光标

## 文本选中

user-select属性，有些文字需要能被选中，有些不要能被选中。

```css
user-select: none|auto|text|contain|all;
```

属性取值：

none :  元素和子元素的文本将无法被选中

text :  文本可以被选中

auto :  文本将根据浏览器的默认属性进行选择

all  :  当所有内容作为一个整体时可以被选择。如果双击或者在上下文上点击子元素，那么被选择的部分将是以该子元素向上回溯的最高祖先元素

contain、element :  可以选择文本，但选择范围受元素边界的约束，也就是选择的文本将包含在该元素的范围内。只支持Internet Explorer