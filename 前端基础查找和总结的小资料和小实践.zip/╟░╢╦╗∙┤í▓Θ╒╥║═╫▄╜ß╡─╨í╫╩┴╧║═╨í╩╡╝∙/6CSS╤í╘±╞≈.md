# CSS选择器（2）——复杂选择器

除了之前介绍的一个简单的CSS选择器外，随着CSS版本的提升，大量的新选择器出现。这使的对元素的选择更加精准、可选择的余地更多了。

## 简单选择器复习

选择器：标签选择器，id选择器（#前缀），class选择器（.前缀）

选择器组合：无符号（交集操作符），空格（后辈操作符），逗号（并集操作符）

## CSS选择器列表

| 选择器               | 例子                 | 描述                                                 | CSS Level |
| -------------------- | -------------------- | ---------------------------------------------------- | --------- |
| .class               | .level1_li           | 选择class="level1_li"的所有元素                      | 1         |
| id                   | #btn_update          | 选择id=“btn_update”的一个元素                        | 1         |
| element              | div                  | 选择所有div元素                                      | 1         |
| element,element      | div,p                | 选择所有div元素和所有p元素（并集选择器）             | 1         |
| element element      | div p                | 选择div元素内部的所有p元素                           | 1         |
| :link                | a:link               | 选择所有未被访问的链接。                             | 1         |
| :visited             | a:visited            | 选择所有已被访问的链接。                             | 1         |
| :active              | a:active             | 选择活动链接。                                       | 1         |
| :hover               | a:hover              | 选择鼠标指针位于其上的链接。                         | 1         |
| ::first-letter       | p:first-letter       | 选择每个p元素的首字母。（匹配文本块的首字母）        | 1         |
| ::first-line         | p:first-line         | 选择每个p元素的首行。（匹配文本块的首行）            | 1         |
| :lang                |                      | 匹配基于lang全局属性值                               | 1         |
| *                    |                      | 选择所有元素                                         | 2         |
| element>element      | div>p                | 选择父元素为div元素的所有p元素                       | 2         |
| element+element      | div+p                | 选择紧接在div元素之后的一个p元素。(只能选择一个)     | 3         |
| ement~element        | p~ul                 | 选择前面有p元素的每个ul元素。(可以选择多个)          | 2         |
| [attribute]          | [target]             | 选择带有target属性所有元素                           | 2         |
| [attribute=value]    | [target=_blank]      | 选择target="_blank"的所有元素                        | 2         |
| [attribute~=value]   | [class~=flower]      | 选择class属性中包含flower的元素（空格分隔）          | 2         |
| :focus               | input:focus          | 选择获得焦点的input元素                              | 2         |
| ::before             | p:before             | 在每个p元素的内容之前插入行内子元素                  | 2         |
| ::after              | p:after              | 在每个p元素的内容之后插入行内子元素                  | 2         |
| [attribute*=value]   | a[src*="abc"]        | 选择其src属性中包含"abc"子串的每个a元素              | 3         |
| [attribute^=value]   | a[src^="http"]       | 选择其src属性值以"http"开头的每个a元素               | 3         |
| [attribute$=value]   | a[src$=".pdf"]       | 选择其src属性以".pdf"结尾的所有a元素                 | 3         |
| E:root               | :root                | 选择文档的根元素。（总是返回html元素）               | 3         |
| :first-child         | p:first-child        | 选择属于父元素的首个子元素，且该子元素必须是p        | 3         |
| :last-child          |                      |                                                      | 3         |
| :only-child          | p:only-child         | 匹配只有一个子元素的父元素。（匹配的是父元素）       | 3         |
| :only-of-type        | p:only-of-type       | 选择属于其父元素唯一的p元素                          | 3         |
| :nth-child(n)        | p :nth-child(2)      | 选择属于p元素的第二个子元素                          | 3         |
| :nth-last-child(n)   |                      |                                                      | 3         |
| :nth-of-type(n)      | div p:nth-of-type(2) | 选择属于div元素的第二个p元素                         | 3         |
| :nth-last-of-type(n) |                      |                                                      | 3         |
| :first-of-type       | p:first-of-type      | 选择属于其父元素的首个p元素                          | 3         |
| :last-of-type        | p:last-of-type       | 选择属于其父元素的最后 p元素                         | 3         |
| :empty               | p:empty              | 选择没有子元素的每个p元素（包括文本节点）。          | 3         |
| :default             |                      | 匹配默认元素                                         | 3         |
| :valid               |                      | 符合输入验证要求的input元素                          | 3         |
| :invalid             |                      | 不符合输入验证要求的input元素                        | 3         |
| :in-range            |                      | 选择限定范围的input元素                              | 3         |
| :out-of-range        |                      | 选择不在限定范围的input元素                          | 3         |
| :required            |                      | 选择必须的input元素（对应input元素中的required属性） | 3         |
| :optional            |                      | 选择可选的input元素                                  | 3         |
| :enabled             |                      | 选择每个启用的input元素                              | 3         |
| :disabled            |                      | 选择每个禁用的 input元素                             | 3         |
| :checked             |                      | 选择每个被选中的input元素                            | 3         |
| :target              |                      | 选择当前活动的 #news 元素                            | 3         |
| :not(selector)       |                      | 选择非p元素的每个元素                                | 3         |
| ::selection          |                      | 选择被用户选取的元素部分                             | 3         |

## 对复杂选择器的分析

### 对空格与大于号的解析

div p和div>p的区别
空格指的是某个标签内的某些标签，可以该标签子标签也可以该标签的孙子标签或更低的标签。
大于号指的是某个标签内的某些子标签，而且只能是子标签。

### 对加号与小波浪线符号的解析

+选择的是某个标签之后的一个兄弟标签。
注意：不是子标签。

~与+的区别：

- ~是选择多个标签，这些标签的特点是前面有另一个标签。比如：p~ul	选择多个ul标签，ul标签的前面有一个p标签。
- +是选择一个标签，这个标签的特点是另一个标签的后一个标签。比如：div+p	选择一个p标签，这个p标签的前面有一个div标签。

~与+的共同点：

- 选择的都是兄弟标签，而不是父子标签。
- 选择的标签不一定是紧跟在某标签之后的，可以有间隔。

### 对属性选择器的解析

[attribute=value]这种写法中，value不用双引号或单引号。比如：

```js
var nodes=document.querySelectorAll('[type=number]');
```

对E[attribute~=value]选择器的解释

该选择器的完整含义是：选择具有attribute属性且属性值为一用空格分隔的字词列表，其中一个等于value的元素。这里的value不能包含空格。
该选择器似乎主要是用在对class属性的定位上的。因为一般情况下，标签属性中的值，只有class中会有用空格分隔的多个字符串。

例子：

```html
<div class="level1 divButton"></div>
```

使用属性选择器选择以上的div元素，如何操作？

```css
[class=divButton]{}		/*这种方法不可行*/
[class~=divButton]{}	/*这种方法可行*/
```

## 伪元素和伪类

伪选择器分为两种：伪元素和伪类

- 伪类用于已有元素处于某个状态时，为其添加对应的样式，这个状态是根据用户行为而动态变化的。伪类以单冒号为前缀。
- 伪元素用于创建一些不在DOM树中的元素，并为其添加样式。伪元素以双冒号为前缀。

伪元素选择器的前缀是两个冒号字符（::），但浏览器认为选择器只有一个冒号。这样它的格式就跟伪类选择器的格式一致了。虽然CSS3标准要求伪元素使用双冒号的写法，但也依然支持单冒号的写法。为了向后兼容，建议在目前还是使用单冒号的写法。

## 动态伪类选择器

E:link、E:visited、E:active、E:hover、E:focus

锚点伪类的设置必须遵守顺序：link-visited-hover-active。

## 目标伪类选择器

E:target

## 语言伪类选择器

E:lang

## UI元素状态伪类选择器

E:checked、E:enabled、E:disabled

## 结构伪类选择器

E:first-child、E:last-child、F E:nth-child(n)、E F:nth-last-child(n)、E F:nth-last-child(n)、E:only-child

E:nth-of-type(n)、E:nth-last-of-type(n)、E:first-of-type、E:last-of-type、E:only-of-type

E:root、E:empty

### 对\*-child和\*-of-type类选择器的解析

#### 对:only-child选择器的解释

最常见的用法是：

```css
parentElement childeElement:only-child/*某类父元素中只有一个特定的子元素，同时关注父元素和子元素*/
childeElement:only-child			/*任意父元素中只有一个特定的子元素，只关注子元素*/
parentElement :only-child			/*某类父元素中只有一个子元素，只关注父元素*/
```

解析：

以上例子中，关注的点是不同的。但都有一个共同点，即：父元素中只能有一个子元素，不管第二子元素与第一个元素是否一致，都不行。

#### 对E:first-of-type与E:first-child选择器的解释

- :first-child 匹配的是某父元素的第一个子元素，可以说是结构上的第一个子元素。
- :first-of-type 匹配的是某父元素下相同类型子元素中的第一个，比如 p:first-of-type，就是指所有类型为p的子元素中的第一个。这里不再限制是第一个子元素了，只要是该类型元素的第一个就行了。

#### 对E:nth-child(n)和E:nth-of-type(n)的解释

- E:nth-child(n)选择器的含义是：匹配父元素中的第n个子元素E。这里关注的是父元素中的所有子元素，而不是某种类型的子元素。如果第n个子元素不是E，则选择失败。

- E:nth-of-type(n)选择器的含义是：匹配父元素中的所有E元素中的第n个元素。这里关注的是某一类元素中的第n个。

  以上两者的区别:nth-child()只关注子元素不管类型；而:nth-of-type()关注的是某一类子元素。所以nth-child()会因为某个位置上的子元素不是要选择的子元素而选空。

#### n的取值问题

以上所有接受参数n的选择器中，对n类型要求都是一样。
n可以是整数，如1，2，3，4；也可以是关键字odd（奇数）、even（偶数）；还可以是公式，如2n+1等。
n还可以是负值，如：-n+3指的前三个。
需要重点强调的是：n的初始值是1，而非0。

#### 结构伪类选择器的一般写法：

```css
parentElement childElement:first-child/*选择父元素中的第一个子元素并且该子元素必须是childElement*/
parentElement :first-child			   /*选择父元素中的第一个子元素*/
parentElement childElement:first-of-type /*选择父元素中childElement的第一个子元素*/
```

拥有相同的关键含义，只由于前缀的不同，而有不同的进一步语义而已。

#### 主要解析

尽管在这些选择器的含义中都包括了父元素的概念，但实际上选择器中没有出现父元素。这里的父元素只是指明同一个父元素而已。冒号前的元素E指的都要选择的元素而非父元素。
一般来说除非对整个页面的某个元素进行操作，否则结构伪类选择器之前一般都要加上限制性选择器，这个限制性的选择器就是父元素。

## 否定伪类选择器

E:not(F)

## 伪元素

### ::before和::after

::before

在当前元素的内容前面插入一个子元素。插入的元素为内联元素。  需要注意的是，使用::before时， 必须使用content来指定子元素的内容。 

:before与:after的的使用。

```css
<style type="text/css">
	a:before{content:"click here to "}
	a:after{content:"!"}
</style>
```

```html
...
<a href="...">大家好</a>
...
```

显示效果：

```
click here to 大家好!
```

当子元素浮动，父元素塌陷的时候如果加入一个div标签，然后设置其clear属性。会在父标签中加入不用元素。此时可以使用使用::after伪元素，能过CSS加入这个标签。

```css
/*#out是父元素*/
#out::after{		
    content:'';
    display: block;
    clear:both;
}
```

::first-letter

::first-line

::selection


