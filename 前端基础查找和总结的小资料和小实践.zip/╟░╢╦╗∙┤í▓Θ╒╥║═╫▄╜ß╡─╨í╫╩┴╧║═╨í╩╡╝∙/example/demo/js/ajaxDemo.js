import AjaxUtils from '../../js/ajaxUtils.js';

let ajaxUtil=new AjaxUtils();

function init(){
    initCity();
}
function initCity(){
    let xhr=new XMLHttpRequest();
    xhr.open("get","../data/province.json",true);
    xhr.responseType="json";
    xhr.addEventListener("readystatechange",()=>{
        if(xhr.readyState==4&&xhr.status==200){
            let node=document.getElementById("province");
            let option0=document.createElement("option");
            option0.value="00";
            option0.innerHTML="请选择省份";
            option0.selected=true;
            node.appendChild(option0);
            //let json=JSON.parse(xhr.responseText);
            xhr.response.data.forEach(item=>{
                let option=document.createElement("option");
                option.value=item.code;
                option.innerHTML=item.name;
                node.appendChild(option);
            });
        }
    },false);
    xhr.send(null);
}
document.getElementById("province").addEventListener("change",()=>{
    let provinceCode=document.getElementById("province").value;
    ajaxUtil.get("../../data/city.json",xhr=>{
        let node=document.getElementById("city");
        node.length=0;
        let option0=document.createElement("option");
        option0.value="0000";
        option0.innerHTML="请选择城市";
        option0.selected=true;
        node.appendChild(option0);
        xhr.response.data.filter(item=>item.code.startsWith(provinceCode)).forEach(item=>{
            let option=document.createElement("option");
            option.value=item.code;
            option.innerHTML=item.name;
            node.appendChild(option);
        });
    });

},false);
window.addEventListener("load",init,false);